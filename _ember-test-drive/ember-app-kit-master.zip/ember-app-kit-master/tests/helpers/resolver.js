import Resolver from 'resolver';

var resolver = Resolver.create();

resolver.namespace = {
  modulePrefix: 'appkit'
};

export default resolver;
