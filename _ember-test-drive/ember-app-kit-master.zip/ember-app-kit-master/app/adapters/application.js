export default DS.FixtureAdapter.extend();
