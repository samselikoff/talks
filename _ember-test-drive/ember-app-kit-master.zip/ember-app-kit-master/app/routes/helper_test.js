export default Ember.Route.extend({
  model: function() {
    return {
      name: "rebmE"
    };
  }
});
