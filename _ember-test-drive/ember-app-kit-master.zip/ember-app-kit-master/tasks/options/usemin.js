module.exports = {
  html: ['dist/index.html'],
};
